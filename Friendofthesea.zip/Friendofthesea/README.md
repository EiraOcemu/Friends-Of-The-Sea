# Friends-Of-The-Sea
A Balatro Mod where a bunch of Jokers are based on my Friends!

All Custum joker art is done and Made by myself.
To Run this Mod, you Need: https://github.com/ethangreen-dev/lovely-injector and https://github.com/Steamodded/smods
